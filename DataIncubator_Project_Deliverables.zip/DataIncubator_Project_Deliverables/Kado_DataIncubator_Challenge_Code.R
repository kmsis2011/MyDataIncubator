

####################################################################################################################
####################################################################################################################
# This program is designed to resolve the Cars at an intersection challenge: 
# ***********************************BELOW IS THE CHALLENGE: *******************************************************
## A circular road has N positions labeld 0 through N-1 where adjencent positions are connected to each other 
## and positoon N-1  is connected to 0. M cars start at position 0 through M-1 (inclusive). A car can make a valid 
## move by moving forward one position (or goes from N-1 to 0) if it is moving into is empty.
## at each turn, only consider cars that have a valid move available and make of the valid moves that
## you choose randomly with equal probability. After T rounds, we compute the average (A) and standard deviation (S)
## of the position of the cars. 
####################################################################################################################
####################################################################################################################

####################################################################################################################
####################################################################################################################
# **********************BELOW IS THE MATHEMATICAL CONCEPTUALIZATION OF THE CHALLENGE: ******************************

## I. Calculate the Average (A) 
##  1. At step 1, only one movement is possible with probability p=1 if and only if N>M 
##  2. at each step, we calculate the probability of choosing a car to move with prob=1/k (k=number of cars eligible to move)
##     given previous movements (1/(k-1)!) made that car movement possible). 
##  3. The position of eligible cars is the sum of these probabilistic distances for each car
##  4. For steps less than N-M+1, a new car is potentially eligible to move at each step
##     For example at step 1: A=1, at step 2: A=1/2!+1  +  1/2!, at step 3, A=1/3!+1/2!+1  +  1/3!+1/2! +  1/3!
##     The formula can be generalized and simplified as follow:
##     for A, stepn+1= stepn + 1/n!. 
##     Similarly, for V (variance), 
##     at step 1, V=0, , at step 2: A=1/2*1/2!+1  +  1/2*1/2!, at step 3, A=2/3*1/3!+1/2!+1  +  2/3*1/3!+1/2! +  2/3*1/3!
##     can be generalized and simplified as: stepn+1=stepn + 1/(n+1) * 1/(n-1)!
##  5. For steps above N-M, A formula becomes: stepn= stepN-M + 1/(N-M)! * sum(1/(N-M)^k)k=0 to k-N+M-1
##   V formula becomes: stepn= stepN-M + 1/(N-M)! * sum(1/(N-M)^k *(N-M-1/N-M)^k)k=0 to k-N+M-1
####################################################################################################################
####################################################################################################################


## Initilization first movement 
step<-c(1)
A<-c(1)
V<-c(0)


N<-25 # Number of position at intersection
M<-10 # number of cars
T<-50 # Total number of steps
D<-N-M # Available spots for cars to move
DM<-N-M+1 # first step after last car made it initial movement


## Initialization DATA SET
CarPosition<-data.frame(step, A, V)

if (M<N){ # No movement is possible if M>=N
  
  if (T<=D){ # for rounds of distance less than the number of spots, a new car is potentially eligible at each step
    for (k in 2:T){
      
      ## Average A of Previous step
      previousA<-CarPosition[which(CarPosition$step==k-1),2]
      
      
## Add new record for Cars position
      CarPosition<-rbind(CarPosition, data.frame(step=c(k), A=c(previousA+1/factorial(k-1)), V=c(sqrt(previousA+(1/k)*(1/factorial(k-2))))))   
    }
    
  } else{
    
   
    for (k in 2:D){

      ## Average A of Previous step
      previousA<-CarPosition[which(CarPosition$step==k-1),2]


      ## Add new record for Cars position
      CarPosition<-rbind(CarPosition, data.frame(step=c(k), A=c(previousA+1/factorial(k-1)), V=c(sqrt(previousA+(1/k)*(1/factorial(k-2))))))
    }
    
    

    
    
    
    
    
    
    ## Last step Average (A) position
    LaststepA<-CarPosition[which(CarPosition$step==N-M),2]
    
    
    for (k in DM:T){ # For steps above the numbers initial available steps. All cars have met eligibility to make their first movement
      
      
      NewPositionA<-0
      NewPositionV<-0
    
      AllCarsIn<-k-N+M-1
      
      for (j in 0:AllCarsIn){ ## at this stage a fixed number of cars are eligible to make the next move
        NewPositionA<-sum(NewPositionA, 1/(N-M)^j)
        NewPositionV<-sum(NewPositionV, 1/(N-M)^j*(((N-M-1)/(N-M))^j))
      }
      
      ## Add new record for Cars position
      CarPosition<-rbind(CarPosition, data.frame(step=c(k), A=c(LaststepA+1/factorial(N-M)*NewPositionA), V=c(sqrt(LaststepA+1/factorial(N-M)*NewPositionV))))
    }
      
   
    
  }
  
  
  
  
} else {
  A<-0
  S<-0
}

## we calculate Average A as the average of all steps values of A
Expected_A<-mean(CarPosition$A)
Standard_Deviation_A<-sd(CarPosition$A)

## we calculate Average S as the average of all steps values
Expected_S<-mean(CarPosition$V)
Standard_Deviation_S<-sd(CarPosition$V)

## clean after us
rm(AllCarsIn, A, D, DM, j, k, LaststepA,M, N, previousA, step, T, NewPositionA, NewPositionV, V)




