
####################################################################################################################
####################################################################################################################
## ************************ WOMEN EMPOWERMENT INDEX

## In this example, we used preprocessed data that was already been published for exploratory analysis. The row data is still yet
## to be cleared for publication. We therefore do not provide any more details it. We already already have built the 
## complete code for caculating the WOMEN EMPOWERMENT INDEX and many other indicators that we are going to be working 
# with in this project but would not release them at this time in this project. 
####################################################################################################################
####################################################################################################################






#Load libraries 
library(fmsb)
require(dplyr)
library(e1071)
library(ggplot2)
library(gmodels)
library(data.table)
library(MASS)
library(cluster)
library(caTools)
library(factoextra)
library(fpc)
library(NbClust)


# to perform different types of hierarchical clustering
# package functions used: daisy(), diana(), clusplot()
myclusterDistance <- daisy(myDataIncubator, metric = c("gower"))


#------------ DIVISIVE CLUSTERING ------------#
divisive.clust <- diana(as.matrix(myclusterDistance), diss = TRUE, keep.diss = TRUE)
#plot(divisive.clust, main = "Divisive")


#------------ AGGLOMERATIVE CLUSTERING ------------#
# I am looking for the most balanced approach
# Complete linkages is the approach that best fits this demand - I will leave only this one here, don't want to get it cluttered
# complete
aggl.clust.c <- hclust(myclusterDistance, method = "complete")








fit <- kmeans(mydata[,vec], 4, nstart=25)

plotcluster(mydata[,vec], fit$cluster, xlab=10, ylab=10)
table(fit$cluster)



MyFinal<-cbind(mydata, cluster=fit$cluster)
saveRDS(MyFinal, file="MyFinal.rds")



sink("Myoutputcluster.txt")
table(MyFinal$cluster, MyFinal$reg)
table(MyFinal$cluster, MyFinal$Sex)
table(MyFinal$cluster, MyFinal$rural)
table(MyFinal$cluster, MyFinal$hhhead_marital)
table(MyFinal$cluster, MyFinal$hhhead_education)
sink()











