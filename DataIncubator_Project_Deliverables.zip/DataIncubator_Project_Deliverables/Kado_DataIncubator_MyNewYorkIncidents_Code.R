
####################################################################################################################
####################################################################################################################
## This program is designed for the first challenge; Section 1 
## about the New York City Fire Department keeps a log of detailed information on incidents handled by FDNY units
####################################################################################################################
####################################################################################################################



library(data.table) # Reading big datasets 
library(doBy) # use summaryby function
#library(lubridate) # format dates 


## Set a minimum number of digits for outputs
options(digits=14)

## Reading The main data set
Incidents<-fread('Incidents_Responded_to_by_Fire_Companies.csv', header=T, stringsAsFactors = F)

## View a few records 
First20Records<-head(Incidents, n=20)

## Outputs variables names
names(Incidents)


## Question 1 starts here
descp<-merge(data.frame(table(Incidents$INCIDENT_TYPE_DESC)), data.frame(prop.table(table(Incidents$INCIDENT_TYPE_DESC))), by=c("Var1"))
## Question 1: What proportion of FDNY responses in this dataset correspond to the most common type of incident?
# Answer:  0.3614828304


## Question 2 starts here
AverageUnitsByIncidentType<-summaryBy(UNITS_ONSCENE ~ INCIDENT_TYPE_DESC, data = Incidents[which(!is.na(Incidents$UNITS_ONSCENE)),], FUN = function(x) { c(m = mean(x)) }) 
Ratio<-round(AverageUnitsByIncidentType[which(AverageUnitsByIncidentType$INCIDENT_TYPE_DESC =="111 - Building fire"),2]/AverageUnitsByIncidentType[which(AverageUnitsByIncidentType$INCIDENT_TYPE_DESC =="651 - Smoke scare, odor of smoke"),2], digits = 9)
## Question 2: What is the ratio of the average number of units that arrive to a scene of an incident classified as '111 - Building fire' to the number that arrive for '651 - Smoke scare, odor of smoke'?
## Answer: 2.759759514


## Question 3 starts here
Incidents$FalseIncidents<-as.factor(ifelse(Incidents$INCIDENT_TYPE_DESC=="710 - Malicious, mischievous false call, other", "FalseCalls", "Other"))
prop.table(table(Incidents$BOROUGH_DESC, Incidents$FalseIncidents),1)
FalseCalls<-data.frame(prop.table(table(Incidents$BOROUGH_DESC, Incidents$FalseIncidents),1))
FalseC<-round(FalseCalls[which(FalseCalls$Var1=="3 - Staten Island" & FalseCalls$Var2== "FalseCalls"),3]/FalseCalls[which(FalseCalls$Var1=="1 - Manhattan" & FalseCalls$Var2== "FalseCalls"),3], digits = 9)
## question 3: How many times more likely is an incident in Staten Island a false call compared to in Manhattan? The answer should be the ratio of Staten Island false call rate to Manhattan false call rate. A false call is an incident for which 'INCIDENT_TYPE_DESC' is '710 - Malicious, mischievous false call, other'.
## Answer: 1.624381947


## Question 4 starts here
TimeToArrival<-Incidents[, c("IM_INCIDENT_KEY","INCIDENT_TYPE_DESC","INCIDENT_DATE_TIME","ARRIVAL_DATE_TIME")]
TimeToArrival$StartTime<-as.POSIXct(TimeToArrival$INCIDENT_DATE_TIME, format='%m/%d/%Y %I:%M:%S %p')
TimeToArrival$ArrivTime<-as.POSIXct(TimeToArrival$ARRIVAL_DATE_TIME, format='%m/%d/%Y %I:%M:%S %p')
TimeToArrival$NbMn<-as.numeric((TimeToArrival$ArrivTime-TimeToArrival$StartTime)/60)
TimeToArriv<-TimeToArrival[which(TimeToArrival$INCIDENT_TYPE_DESC=="111 - Building fire"),]
summary(TimeToArriv$NbMn)
## Question 4: Check the distribution of the number of minutes it takes between the time a '111 - Building fire' incident has been logged into the Computer Aided Dispatch system and the time at which the first unit arrives on scene. What is the third quartile of that distribution. Note: the number of minutes can be fractional (ie, do not round).
## Answer: 4.150


## Question 5 starts here
TimeToArrival$CookingFire<-ifelse(TimeToArrival$INCIDENT_TYPE_DESC=="113 - Cooking fire, confined to container", "Cooking Fire", "Other")
TimeToArrival$CookingHour<-substr(TimeToArrival$StartTime, 11,13)
prop.table(table(TimeToArrival$CookingHour, TimeToArrival$CookingFire),1)
## Question 5: We can use the FDNY dataset to investigate at what time of the day people cook most. Compute what proportion of all incidents are cooking fires for every hour of the day by normalizing the number of cooking fires in a given hour by the total number of incidents that occured in that hour. Find the hour of the day that has the highest proportion of cooking fires and submit that proportion of cooking fires. A cooking fire is an incident for which 'INCIDENT_TYPE_DESC' is '113 - Cooking fire, confined to container'. Note: round incident times down. For example, if an incident occured at 22:55 it occured in hour 22.
## Answer: 0.050846820


## Question 6 starts here
population<-fread('2010_census_population.csv', header=T, stringsAsFactors = F)
myIncidents<-Incidents[which(Incidents$INCIDENT_TYPE_DESC=="111 - Building fire"),]
myIncidents<-data.frame(table(ZIP_CODE= myIncidents$ZIP_CODE))
myIncidents$ZIP_CODE<-as.numeric(as.character(myIncidents$ZIP_CODE))
myIncidents<-merge(population, myIncidents, by=c("ZIP_CODE"))

#Linear Regression 
scatter.smooth(x=myIncidents$Pop, y=myIncidents$Count, main="Freq ~ Pop")
model <- lm(Freq ~ Pop, data=myIncidents)
summary(model)
## Question 6: What is the coefficient of determination (R squared) between the number of residents at each zip code and the number of inicidents whose type is classified as '111 - Building fire' at each of those zip codes. Note: The 2010 US Census population by zip code dataset should be downloaded from here. You will need to use both the FDNY responses and the US Census dataset. Ignore zip codes that do not appear in the census table.
## Answer: 0.597339395



## Question 7 starts here
Incidents$Duration<-Incidents$TOTAL_INCIDENT_DURATION/60
myIncidents<-Incidents[which(!is.na(Incidents$Duration)),]
myIncidents$IntDuration<-ifelse(myIncidents$Duration>=20 & myIncidents$Duration<30, "20-30", 
                        ifelse(myIncidents$Duration>=30 & myIncidents$Duration<40, "30-40",
                        ifelse(myIncidents$Duration>=40 & myIncidents$Duration<50, "40-50",
                        ifelse(myIncidents$Duration>=50 & myIncidents$Duration<60, "50-60",
                        ifelse(myIncidents$Duration>=60 & myIncidents$Duration<=70, "60-70", NA)))))
myIncidents<-myIncidents[which(!is.na(myIncidents$IntDuration) & myIncidents$CO_DETECTOR_PRESENT_DESC %in% c("Yes", "No")),]
myIncidentsCount<-count(myIncidents,vars=c("IntDuration", "CO_DETECTOR_PRESENT_DESC"))
myIncidentsCountWDector<-myIncidentsCount[which(myIncidentsCount$CO_DETECTOR_PRESENT_DESC=="Yes"),c("IntDuration", "freq")]
myIncidentsCountWDector$Detectorfreq<-myIncidentsCountWDector$freq/sum(myIncidentsCountWDector$freq)
myIncidentsCountWoDector<-myIncidentsCount[which(myIncidentsCount$CO_DETECTOR_PRESENT_DESC=="No"),c("IntDuration", "freq")]
myIncidentsCountWoDector$NoDetectorfreq<-myIncidentsCountWoDector$freq/sum(myIncidentsCountWoDector$freq)
myIncidentsRatio<-merge(myIncidentsCountWDector[,c("IntDuration", "Detectorfreq")], myIncidentsCountWoDector[,c("IntDuration", "NoDetectorfreq")], by=c("IntDuration"))
myIncidentsRatio$Ratio<-myIncidentsRatio$NoDetectorfreq/myIncidentsRatio$Detectorfreq
myIncidentsRatio$MidPoint<-ifelse(myIncidentsRatio$IntDuration=="20-30", (20+30)/2, 
                           ifelse(myIncidentsRatio$IntDuration=="30-40", (30+40)/2, 
                           ifelse(myIncidentsRatio$IntDuration=="40-50", (40+50)/2, 
                           ifelse(myIncidentsRatio$IntDuration=="50-60", (50+60)/2,                         
                           ifelse(myIncidentsRatio$IntDuration=="60-70", (60+70)/2, 0)))))   
#Linear Regression 
scatter.smooth(x=myIncidentsRatio$MidPoint, y=myIncidentsRatio$Ratio, main="Ratio ~ MidPoint")
model <- lm(Ratio ~ MidPoint, data= myIncidentsRatio)
summary(model)
#y is Ratio
#x is midpoint = 39
y<-0.0500420485224*39 - 0.6032732376683
## Question 7: For this question, only consider incidents that have information about whether a CO detector was present or not. We are interested in how many times more likely it is that an incident is long when no CO detector is present compared to when a CO detector is present. For events with CO detector and for those without one, compute the proportion of incidents that lasted 20-30, 30-40, 40-50, 50-60, and 60-70 minutes (both interval boundary values included) by dividing the number of incidents in each time interval with the total number of incidents. For each bin, compute the ratio of the 'CO detector absent' frequency to the 'CO detector present' frequency. Perform a linear regression of this ratio to the mid-point of the bins. From this, what is the predicted ratio for events lasting 39 minutes?
## Answer: 1.3483666547053


## Question 8 starts here
myIncidents$More60<-ifelse(myIncidents$IntDuration=="60-70", "Yes", "No")
chisq.test(table(myIncidents$CO_DETECTOR_PRESENT_DESC, myIncidents$More60))
## Question 8: Calculate the chi-square test statistic for testing whether an incident is more likely to last longer than 60 minutes when CO detector is not present. Again only consider incidents that have information about whether a CO detector was present or not.
## Answer: 106.525022465



